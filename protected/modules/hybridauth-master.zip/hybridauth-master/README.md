HybridAuth
==============

Provides a wrapper for Hybrid_Auth for the Yii framework